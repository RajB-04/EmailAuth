package com.emailverifier.repository;

import com.emailverifier.entity.DisposableDomain;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for DisposableDomain entity
 */
@Repository
public interface DisposableDomainRepository extends JpaRepository<DisposableDomain, Long> {
    
    /**
     * Find a disposable domain by domain name (case insensitive)
     */
    Optional<DisposableDomain> findByDomainIgnoreCase(String domain);
    
    /**
     * Check if a domain exists and is active
     */
    boolean existsByDomainIgnoreCaseAndActiveTrue(String domain);
    
    /**
     * Find all active disposable domains
     */
    List<DisposableDomain> findByActiveTrue();
    
    /**
     * Find active disposable domains with pagination
     */
    Page<DisposableDomain> findByActiveTrue(Pageable pageable);
    
    /**
     * Count active disposable domains
     */
    long countByActiveTrue();
    
    /**
     * Find domains containing a specific string (for search functionality)
     */
    @Query("SELECT d FROM DisposableDomain d WHERE d.active = true AND d.domain LIKE %:searchTerm%")
    List<DisposableDomain> findActiveDomainsBySearchTerm(@Param("searchTerm") String searchTerm);
    
    /**
     * Get a sample of domains for display purposes
     */
    @Query("SELECT d FROM DisposableDomain d WHERE d.active = true ORDER BY d.domain")
    List<DisposableDomain> findSampleActiveDomains(Pageable pageable);
    
    /**
     * Check if domain exists (case insensitive)
     */
    boolean existsByDomainIgnoreCase(String domain);
    
    /**
     * Delete inactive domains (cleanup utility)
     */
    void deleteByActiveFalse();
} 