package com.emailverifier.controller;

import com.emailverifier.dto.BulkEmailVerificationRequest;
import com.emailverifier.dto.BulkEmailVerificationResponse;
import com.emailverifier.dto.EmailVerificationRequest;
import com.emailverifier.dto.EmailVerificationResponse;
import com.emailverifier.service.EmailVerificationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * REST Controller for email verification API endpoints
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*") // Allow CORS for API endpoints
public class EmailVerificationRestController {
    
    private final EmailVerificationService emailVerificationService;
    
    /**
     * Verify a single email address
     * POST /api/verify
     */
    @PostMapping("/verify")
    public ResponseEntity<EmailVerificationResponse> verifyEmail(
            @Valid @RequestBody EmailVerificationRequest request) {
        
        log.info("API: Verifying email: {}", request.getEmail());
        
        try {
            EmailVerificationResponse response = emailVerificationService.verifyEmail(request.getEmail());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error verifying email: {}", e.getMessage(), e);
            EmailVerificationResponse errorResponse = EmailVerificationResponse.invalid(
                request.getEmail(), 
                "Server error: " + e.getMessage()
            );
            return ResponseEntity.status(500).body(errorResponse);
        }
    }
    
    /**
     * Verify multiple email addresses in bulk
     * POST /api/bulk-verify
     */
    @PostMapping("/bulk-verify")
    public ResponseEntity<BulkEmailVerificationResponse> verifyBulkEmails(
            @Valid @RequestBody BulkEmailVerificationRequest request) {
        
        log.info("API: Verifying {} emails in bulk", request.getEmails().size());
        
        try {
            BulkEmailVerificationResponse response = emailVerificationService.verifyBulkEmails(request.getEmails());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error verifying bulk emails: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body(
                BulkEmailVerificationResponse.builder()
                    .results(java.util.Collections.emptyList())
                    .total(0)
                    .disposableCount(0)
                    .suspiciousCount(0)
                    .timestamp(java.time.Instant.now().toString())
                    .build()
            );
        }
    }
    
    /**
     * Get statistics about disposable domains
     * GET /api/stats
     */ 
    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getStatistics() {
        log.info("API: Getting statistics");
        
        try {
            EmailVerificationService.DomainStatistics stats = emailVerificationService.getStatistics();
            java.util.List<String> sampleDomains = emailVerificationService.getSampleDomains(20);
            
            Map<String, Object> response = Map.of(
                "totalDomains", stats.getTotalDomains(),
                "activeDomains", stats.getActiveDomains(),
                "sampleDomains", sampleDomains,
                "timestamp", java.time.Instant.now().toString()
            );
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            log.error("Error getting statistics: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body(
                Map.of("error", "Server error: " + e.getMessage())
            );
        }
    }
    
    /**
     * Health check endpoint
     * GET /api/health
     */
    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> healthCheck() {
        Map<String, Object> health = Map.of(
            "status", "UP",
            "service", "Email Domain Verifier",
            "timestamp", java.time.Instant.now().toString(),
            "version", "1.0.0"
        );
        
        return ResponseEntity.ok(health);
    }
} 