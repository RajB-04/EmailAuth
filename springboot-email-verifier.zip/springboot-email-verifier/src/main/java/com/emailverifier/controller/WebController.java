package com.emailverifier.controller;

import com.emailverifier.service.EmailVerificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * Web Controller for serving Thymeleaf templates
 */
@Controller
@RequiredArgsConstructor
@Slf4j
public class WebController {
    
    private final EmailVerificationService emailVerificationService;
    
    /**
     * Home page - Main email verification interface
     */
    @GetMapping("/")
    public String index(Model model) {
        log.info("Serving home page");
        model.addAttribute("pageTitle", "Email Domain Verifier");
        return "index";
    }
    
    /**
     * Statistics page
     */
    @GetMapping("/stats")
    public String stats(Model model) {
        log.info("Serving statistics page");
        
        try {
            EmailVerificationService.DomainStatistics stats = emailVerificationService.getStatistics();
            List<String> sampleDomains = emailVerificationService.getSampleDomains(20);
            
            model.addAttribute("pageTitle", "Statistics - Email Domain Verifier");
            model.addAttribute("totalDomains", stats.getTotalDomains());
            model.addAttribute("activeDomains", stats.getActiveDomains());
            model.addAttribute("sampleDomains", sampleDomains);
            
        } catch (Exception e) {
            log.error("Error loading statistics: {}", e.getMessage(), e);
            model.addAttribute("error", "Could not load statistics: " + e.getMessage());
        }
        
        return "stats";
    }
    
    /**
     * About page
     */
    @GetMapping("/about")
    public String about(Model model) {
        log.info("Serving about page");
        model.addAttribute("pageTitle", "About - Email Domain Verifier");
        return "about";
    }
} 