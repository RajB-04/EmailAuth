package com.emailverifier.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

/**
 * Entity representing a disposable email domain
 */
@Entity
@Table(name = "disposable_domains", indexes = {
    @Index(name = "idx_domain", columnList = "domain"),
    @Index(name = "idx_active", columnList = "active")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DisposableDomain {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "domain", nullable = false, unique = true, length = 255)
    private String domain;
    
    @Column(name = "active", nullable = false)
    private Boolean active = true;
    
    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;
    
    /**
     * Constructor for creating a new disposable domain
     * @param domain The domain name
     */
    public DisposableDomain(String domain) {
        this.domain = domain.toLowerCase().trim();
        this.active = true;
    }
    
    /**
     * Constructor for creating a new disposable domain with active status
     * @param domain The domain name
     * @param active Whether the domain is active
     */
    public DisposableDomain(String domain, Boolean active) {
        this.domain = domain.toLowerCase().trim();
        this.active = active;
    }
    
    @Override
    public String toString() {
        return "DisposableDomain{" +
                "id=" + id +
                ", domain='" + domain + '\'' +
                ", active=" + active +
                ", createdAt=" + createdAt +
                '}';
    }
} 