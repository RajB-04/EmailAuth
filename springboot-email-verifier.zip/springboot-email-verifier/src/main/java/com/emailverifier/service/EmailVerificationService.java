package com.emailverifier.service;

import com.emailverifier.dto.BulkEmailVerificationResponse;
import com.emailverifier.dto.EmailVerificationResponse;
import com.emailverifier.repository.DisposableDomainRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Service for email domain verification
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class EmailVerificationService {
    
    private final DisposableDomainRepository disposableDomainRepository;
    
    // Email validation pattern
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
    );
    
    // Domain validation pattern
    private static final Pattern DOMAIN_PATTERN = Pattern.compile(
        "^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
    );
    
    /**
     * Verify if an email domain is disposable
     * Results are cached for improved performance
     */
    @Cacheable(value = "domainVerification", key = "#email")
    public EmailVerificationResponse verifyEmail(String email) {
        log.debug("Verifying email: {}", email);
        
        if (email == null || email.trim().isEmpty()) {
            return EmailVerificationResponse.invalid(email, "Email address is required");
        }
        
        email = email.trim().toLowerCase();
        
        // Validate email format
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            return EmailVerificationResponse.invalid(email, "Invalid email format");
        }
        
        // Extract domain
        String domain = extractDomain(email);
        if (domain.isEmpty()) {
            return EmailVerificationResponse.invalid(email, "Could not extract domain from email");
        }
        
        // Validate domain format
        if (!DOMAIN_PATTERN.matcher(domain).matches()) {
            return EmailVerificationResponse.invalid(email, "Invalid domain format");
        }
        
        // Check if domain is disposable
        boolean isDisposable = isDisposableDomain(domain);
        
        if (isDisposable) {
            return EmailVerificationResponse.disposable(email, domain);
        } else {
            return EmailVerificationResponse.legitimate(email, domain);
        }
    }
    
    /**
     * Verify multiple emails in bulk
     */
    public BulkEmailVerificationResponse verifyBulkEmails(List<String> emails) {
        log.debug("Verifying {} emails in bulk", emails.size());
        
        List<EmailVerificationResponse> results = emails.stream()
            .map(this::verifyEmail)
            .collect(Collectors.toList());
        
        return BulkEmailVerificationResponse.from(results);
    }
    
    /**
     * Check if a domain is disposable
     * This method checks both exact matches and parent domain patterns
     */
    @Cacheable(value = "disposableDomains", key = "#domain")
    public boolean isDisposableDomain(String domain) {
        if (domain == null || domain.trim().isEmpty()) {
            return false;
        }
        
        domain = domain.toLowerCase().trim();
        
        // Check exact match
        if (disposableDomainRepository.existsByDomainIgnoreCaseAndActiveTrue(domain)) {
            return true;
        }
        
        // Check parent domain patterns (e.g., test.10minutemail.com -> 10minutemail.com)
        String[] parts = domain.split("\\.");
        if (parts.length > 2) {
            String parentDomain = String.join(".", 
                java.util.Arrays.copyOfRange(parts, parts.length - 2, parts.length));
            return disposableDomainRepository.existsByDomainIgnoreCaseAndActiveTrue(parentDomain);
        }
        
        return false;
    }
    
    /**
     * Extract domain from email address
     */
    private String extractDomain(String email) {
        if (email == null || !email.contains("@")) {
            return "";
        }
        
        String[] parts = email.split("@");
        return parts.length == 2 ? parts[1].toLowerCase().trim() : "";
    }
    
    /**
     * Get statistics about disposable domains
     */
    public DomainStatistics getStatistics() {
        long totalDomains = disposableDomainRepository.count();
        long activeDomains = disposableDomainRepository.countByActiveTrue();
        
        return DomainStatistics.builder()
            .totalDomains(totalDomains)
            .activeDomains(activeDomains)
            .build();
    }
    
    /**
     * Get sample domains for display
     */
    public List<String> getSampleDomains(int limit) {
        return disposableDomainRepository.findSampleActiveDomains(
            org.springframework.data.domain.PageRequest.of(0, limit)
        ).stream()
        .map(domain -> domain.getDomain())
        .collect(Collectors.toList());
    }
    
    /**
     * Statistics about disposable domains
     */
    @lombok.Data
    @lombok.Builder
    public static class DomainStatistics {
        private Long totalDomains;
        private Long activeDomains;
    }
} 