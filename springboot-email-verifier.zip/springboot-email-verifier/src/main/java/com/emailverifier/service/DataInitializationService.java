package com.emailverifier.service;

import com.emailverifier.entity.DisposableDomain;
import com.emailverifier.repository.DisposableDomainRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;
import java.util.Arrays;
import java.util.List;

/**
 * Service to initialize disposable domains data on application startup
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class DataInitializationService implements CommandLineRunner {
    
    private final DisposableDomainRepository disposableDomainRepository;
    
    @Override
    public void run(String... args) throws Exception {
        log.info("Initializing disposable domains data...");
        
        // Check if data already exists
        long existingCount = disposableDomainRepository.count();
        if (existingCount > 0) {
            log.info("Database already contains {} domains. Skipping initialization.", existingCount);
            return;
        }
        
        // Get disposable domains list
        List<String> domains = getDisposableDomains();
        
        // Convert to entities
        List<DisposableDomain> domainEntities = domains.stream()
            .map(DisposableDomain::new)
            .toList();
        
        // Save all domains
        disposableDomainRepository.saveAll(domainEntities);
        
        long finalCount = disposableDomainRepository.count();
        log.info("Successfully initialized {} disposable domains in the database", finalCount);
    }
    
    /**
     * Get the list of common disposable email domains
     */
    private List<String> getDisposableDomains() {
        return Arrays.asList(
            // 10 minute mail services
            "10minutemail.com", "10minutemail.co.za", "10minutemail.de",
            "20minutemail.com", "30minutemail.com", "60minutemail.com",
            
            // Guerrilla Mail
            "guerrillamail.com", "guerrillamail.net", "guerrillamail.org",
            "guerrillamailblock.com", "pokemail.net", "spam4.me",
            
            // Mailinator
            "mailinator.com", "mailinator.net", "mailinator.org",
            "mailinator2.com", "notmailinator.com",
            
            // TempMail
            "tempmail.org", "temp-mail.org", "tempmail.net",
            "tempmail.io", "tempmailo.com", "tempmailaddress.com",
            
            // YOPmail
            "yopmail.com", "yopmail.fr", "yopmail.net",
            "cool.fr.nf", "jetable.fr.nf", "nospam.ze.tc",
            
            // ThrowAway Email
            "throwaway.email", "thrma.com", "1secmail.com",
            "1secmail.org", "1secmail.net",
            
            // Other popular disposable services
            "maildrop.cc", "sharklasers.com", "grr.la",
            "getairmail.com", "fakeinbox.com", "spambox.us",
            "mailnesia.com", "trashmail.com", "dispostable.com",
            "tempail.com", "mytrashmail.com", "mailcatch.com",
            "emailondeck.com", "tempemail.com", "getnada.com",
            "armyspy.com", "cuvox.de", "dayrep.com",
            "einrot.com", "fleckens.hu", "gustr.com",
            "jourrapide.com", "rhyta.com", "superrito.com",
            "teleworm.us", "klzlk.com", "qiott.com",
            "trbvm.com", "zzrgg.com", "jnxjn.com",
            
            // Burner mail services
            "burnermail.io", "mohmal.com", "mailtemp.info",
            "temp-mail.io", "disposablemail.com", "fakemailgenerator.com",
            
            // Additional common ones
            "0-mail.com", "0815.ru", "0clickemail.com",
            "0wnd.net", "0wnd.org", "10mail.org",
            "123-m.com", "1chuan.com", "1pad.de",
            "20email.eu", "2prong.com", "33mail.com",
            "3d-painting.com", "4warding.com", "7tags.com",
            "9ox.net", "a-bc.net", "amilegit.com",
            "anonbox.net", "anonymbox.com", "antichef.com",
            "antichef.net", "antispam.de", "bccto.me",
            "beefmilk.com", "binkmail.com", "bio-muesli.net",
            "bobmail.info", "bodhi.lawlita.com", "bofthew.com",
            "bouncr.com", "boxformail.in", "brefmail.com",
            "brennendesreich.de", "broadbandninja.com", "bsnow.net",
            "buffemail.com", "bugmenot.com", "bumpymail.com",
            "burnthespam.info", "burstmail.info", "buyusedlibrarybooks.org",
            "byom.de", "c2.hu", "card.zp.ua",
            "casualdx.com", "cek.pm", "centermail.com",
            "centermail.net", "chammy.info", "childsavetrust.org",
            "chogmail.com", "choicemail1.com", "clixser.com",
            "cmail.net", "cmail.org", "coldemail.info",
            "correo.blogos.net", "cosmorph.com", "courriel.fr.nf",
            "courrieltemporaire.com", "crapmail.org", "crazymailing.com",
            "cubiclink.com", "curryworld.de", "cust.in",
            "dacoolest.com", "dandikmail.com", "deadaddress.com",
            "deadspam.com", "delikkt.com", "despam.it",
            "despammed.com", "devnullmail.com", "dfgh.net",
            "digitalsanctuary.com", "discardmail.com", "discardmail.de",
            "disposableaddress.com", "disposableemailaddresses.com", "disposableinbox.com",
            "dispose.it", "disposeamail.com", "disposemail.com",
            "dm.w3internet.co.uk.w3internet.co.uk", "dodgeit.com", "dodgit.com",
            "dodgit.org", "donemail.ru", "dontreg.com",
            "dontsendmespam.de", "dump-email.info", "dumpandjunk.com",
            "dumpmail.de", "dumpyemail.com", "e-mail.com",
            "e-mail.org", "e4ward.com", "easytrashmail.com",
            "einmalmail.de", "einrot.de", "email60.com",
            "emailias.com", "emailinfive.com", "emailmiser.com",
            "emailsensei.com", "emailtemporanea.com", "emailtemporanea.net",
            "emailtemporario.com.br", "emailthe.net", "emailtmp.com",
            "emailwarden.com", "emailx.at.hm", "emailxfer.com",
            "emeil.in", "emeil.ir", "emz.net",
            "enterto.com", "ephemail.net", "etranquil.com",
            "etranquil.net", "etranquil.org", "evopo.com",
            "explodemail.com", "fakeinformation.com", "fakemailz.com",
            "fakeoutdoor.com", "fammix.com", "fansworldwide.de",
            "fantasymail.de", "fastacura.com", "fastchevy.com",
            "fastchrysler.com", "fastkawasaki.com", "fastmazda.com",
            "fastmitsubishi.com", "fastnissan.com", "fastsubaru.com",
            "fastsuzuki.com", "fasttoyota.com", "fastyamaha.com",
            "filzmail.com", "fivemail.com", "fr33mail.info",
            "frapmail.com", "front14.org", "fux0ringduh.com",
            "garliclife.com", "get1mail.com", "get2mail.fr",
            "getonemail.com", "getonemail.net", "ghosttexter.de",
            "girlsundertheinfluence.com", "gishpuppy.com", "gmai.com",
            "gowikibooks.com", "gowikicampus.com", "gowikifilms.com",
            "gowikigames.com", "gowikimusic.com", "gowikinetwork.com",
            "gowikitravel.com", "gowikitv.com", "great-host.in",
            "greensloth.com", "gsrv.co.uk", "haltospam.com",
            "hatespam.org", "hidemail.de", "hidzz.com",
            "hmamail.com", "hopemail.biz", "hotpop.com",
            "hulapla.de", "ieatspam.eu", "ieatspam.info",
            "ieh-mail.de", "ikbenspamvrij.nl", "imails.info",
            "inboxalias.com", "inboxclean.com", "inboxclean.org",
            "incognitomail.com", "incognitomail.net", "incognitomail.org",
            "insorg-mail.info", "instant-mail.de", "instantemailaddress.com",
            "ipoo.org", "irish2me.com", "iwi.net",
            "jetable.com", "jetable.net", "jetable.org",
            "jsrsolutions.com", "junk1e.com", "kaspop.com",
            "keepmymail.com", "killmail.com", "killmail.net",
            "klassmaster.com", "koszmail.pl", "kurzepost.de",
            "lawlita.com", "letthemeatspam.com", "lhsdv.com",
            "lifebyfood.com", "link2mail.net", "litedrop.com",
            "lol.ovpn.to", "lookugly.com", "lopl.co.cc",
            "lortemail.dk", "lovemeleaveme.com", "lr78.com",
            "maboard.com", "mail-temporaire.fr", "mail.by",
            "mail.mezimages.net", "mail2rss.org", "mail333.com",
            "mail4trash.com", "mailbidon.com", "mailblocks.com",
            "mailbucket.org", "maildx.com", "maileater.com",
            "mailexpire.com", "mailfa.tk", "mailforspam.com",
            "mailfreeonline.com", "mailguard.me", "mailin8r.com",
            "mailinater.com", "mailinator.gq", "mailincubator.com",
            "mailismagic.com", "mailme.lv", "mailme24.com",
            "mailmetrash.com", "mailmoat.com", "mailnull.com",
            "mailorg.org", "mailpick.biz", "mailrock.biz",
            "mailscrap.com", "mailshell.com", "mailsiphon.com",
            "mailtome.de", "mailtothis.com", "mailtrash.net",
            "mailtv.net", "mailtv.tv", "mailzilla.com",
            "mailzilla.org", "makemetheking.com", "manybrain.com",
            "mbx.cc", "mciek.com", "mega.zik.dj",
            "meinspamschutz.de", "meltmail.com", "messagebeamer.de",
            "mierdamail.com", "mintemail.com", "moburl.com",
            "moncourrier.fr.nf", "monemail.fr.nf", "monmail.fr.nf",
            "monumentmail.com", "mt2009.com", "mt2014.com",
            "mypartyclip.de", "myphantomemail.com", "mysamp.de",
            "myspaceinc.com", "myspaceinc.net", "myspaceinc.org",
            "myspacepimpedup.com", "myspamless.com", "nabuma.com",
            "neomailbox.com", "nepwk.com", "nervmich.net",
            "nervtmich.net", "netmails.com", "netmails.net",
            "neverbox.com", "no-spam.ws", "nobulk.com",
            "noclickemail.com", "nogmailspam.info", "nomail.xl.cx",
            "nomail2me.com", "nomorespamemails.com", "nospam4.us",
            "nospamfor.us", "nospamthanks.info", "nowmymail.com",
            "nullbox.info", "nurfuerspam.de", "objectmail.com",
            "obobbo.com", "odnorazovoe.ru", "oneoffemail.com",
            "onewaymail.com", "onlatedotcom.info", "oopi.org",
            "opayq.com", "ordinaryamerican.net", "otherinbox.com",
            "ovpn.to", "owlpic.com", "pancakemail.com",
            "pjkpjk.com", "plexolan.de", "poczta.onet.pl",
            "politikerclub.de", "poofy.org", "pookmail.com",
            "privacy.net", "proxymail.eu", "prtnx.com",
            "punkass.com", "putthisinyourspamdatabase.com", "pwrby.com",
            "qq.com", "quickinbox.com", "rcpt.at",
            "reallymymail.com", "realtyalerts.ca", "receiveee.com",
            "recursor.net", "regbypass.comsafe-mail.net", "rejectmail.com",
            "rklips.com", "rmqkr.net", "royal.net",
            "rppkn.com", "rtrtr.com", "rumgel.com",
            "s0ny.net", "safe-mail.net", "safersignup.de",
            "safetymail.info", "safetypost.de", "sandelf.de",
            "saynotospams.com", "schafmail.de", "schrott-email.de",
            "secretemail.de", "secure-mail.biz", "selfdestructingmail.com",
            "sendspamhere.com", "shieldedmail.com", "shitmail.me",
            "shitware.nl", "shmeriously.com", "shortmail.net",
            "sibmail.com", "sinnlos-mail.de", "slapsfromlastnight.com",
            "slaskpost.se", "smashmail.de", "smellfear.com",
            "snakemail.com", "sneakemail.com", "snkmail.com",
            "sofimail.com", "sofort-mail.de", "sogetthis.com",
            "soodonims.com", "spam.la", "spamavert.com",
            "spambob.com", "spambob.net", "spambob.org",
            "spambog.com", "spambog.de", "spambog.ru",
            "spambox.info", "spambox.irishspringtours.com", "spamcannon.com",
            "spamcannon.net", "spamcon.org", "spamcorptastic.com",
            "spamcowboy.com", "spamcowboy.net", "spamcowboy.org",
            "spamday.com", "spamex.com", "spamfree24.com",
            "spamfree24.de", "spamfree24.eu", "spamfree24.net",
            "spamfree24.org", "spamgoes.com", "spamgourmet.com",
            "spamgourmet.net", "spamgourmet.org", "spamherelots.com",
            "spamhereplease.com", "spamhole.com", "spamify.com",
            "spaminator.de", "spamkill.info", "spaml.com",
            "spaml.de", "spammotel.com", "spamobox.com",
            "spamoff.de", "spamslicer.com", "spamspot.com",
            "spamthis.co.uk", "spamthisplease.com", "spamtrail.com",
            "spamtroll.net", "speed.1s.fr", "spoofmail.de",
            "stuffmail.de", "super-auswahl.de", "supergreatmail.com",
            "supermailer.jp", "superstachel.de", "suremail.info",
            "talkinator.com", "teewars.org", "temp.emeraldwebmail.com",
            "tempalias.com", "tempe-mail.com", "tempemail.biz",
            "tempemail.co.za", "tempemail.net", "tempinbox.co.uk",
            "tempinbox.com", "tempmail.eu", "tempmail2.com",
            "tempmaildemo.com", "tempmailer.com", "tempmailer.de",
            "tempmailid.com", "thisisnotmyrealemail.com", "throwawayemailaddress.com",
            "tilien.com", "tittbit.in", "tmailinator.com",
            "toiea.com", "tradermail.info", "trash-amil.com",
            "trash-mail.at", "trash-mail.com", "trash-mail.de",
            "trash2009.com", "trashdevil.com", "trashemail.de",
            "trashmail.at", "trashmail.me", "trashmail.ws",
            "trashmailer.com", "trashymail.com", "trashymail.net",
            "turual.com", "twinmail.de", "tyldd.com",
            "uggsrock.com", "umail.net", "upliftnow.com",
            "uplipht.com", "uroid.com", "us.af",
            "venompen.com", "veryrealemail.com", "viditag.com",
            "viewcastmedia.com", "viewcastmedia.net", "viewcastmedia.org",
            "vomoto.com", "vubby.com", "walala.org",
            "walkmail.net", "webemail.me", "weg-werf-email.de",
            "wegwerf-emails.de", "wegwerfadresse.de", "wegwerfemail.com",
            "wegwerfemail.de", "wegwerfmail.de", "wegwerfmail.info",
            "wegwerfmail.net", "wegwerfmail.org", "wetrainbayarea.com",
            "wetrainbayarea.org", "wh4f.org", "whatiaas.com",
            "whatpaas.com", "whatsaas.com", "whopy.com",
            "willhackforfood.biz", "willselldrugs.com", "wuzup.net",
            "wuzupmail.net", "wwwnew.eu", "x.ip6.li",
            "xagloo.com", "xemaps.com", "xents.com",
            "xmaily.com", "xoxy.net", "yapped.net",
            "yeah.net", "yep.it", "yogamaven.com",
            "youmailr.com", "yourdomain.com", "ypmail.webredirect.org",
            "yuurok.com", "yxzx.net", "zehnminutenmail.de",
            "zetmail.com", "zippymail.info", "zoaxe.com",
            "zoemail.net", "zoemail.org"
        );
    }
} 