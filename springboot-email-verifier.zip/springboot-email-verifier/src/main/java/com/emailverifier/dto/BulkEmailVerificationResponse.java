package com.emailverifier.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for bulk email verification response
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BulkEmailVerificationResponse {
    
    private List<EmailVerificationResponse> results;
    private Integer total;
    private Integer disposableCount;
    private Integer suspiciousCount;
    private String timestamp;
    
    /**
     * Create a bulk response from individual results
     */
    public static BulkEmailVerificationResponse from(List<EmailVerificationResponse> results) {
        int disposableCount = (int) results.stream()
                .mapToInt(r -> Boolean.TRUE.equals(r.getIsDisposable()) ? 1 : 0)
                .sum();
        
        int suspiciousCount = (int) results.stream()
                .mapToInt(r -> Boolean.TRUE.equals(r.getIsSuspicious()) ? 1 : 0)
                .sum();
        
        return BulkEmailVerificationResponse.builder()
                .results(results)
                .total(results.size())
                .disposableCount(disposableCount)
                .suspiciousCount(suspiciousCount)
                .timestamp(java.time.Instant.now().toString())
                .build();
    }
} 