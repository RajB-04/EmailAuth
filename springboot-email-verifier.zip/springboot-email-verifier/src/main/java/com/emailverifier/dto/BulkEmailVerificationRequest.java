package com.emailverifier.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for bulk email verification request
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BulkEmailVerificationRequest {
    
    @NotEmpty(message = "Email list cannot be empty")
    @Size(max = 100, message = "Maximum 100 emails allowed per request")
    private List<String> emails;
} 