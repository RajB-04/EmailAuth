package com.emailverifier.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO for email verification response
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmailVerificationResponse {
    
    private String email;
    private String domain;
    private Boolean isValid;
    private Boolean isDisposable;
    private Boolean isSuspicious;
    private String message;
    private String timestamp;
    
    /**
     * Create a response for a disposable email
     */
    public static EmailVerificationResponse disposable(String email, String domain) {
        return EmailVerificationResponse.builder()
                .email(email)
                .domain(domain)
                .isValid(true)
                .isDisposable(true)
                .isSuspicious(true)
                .message("This email appears to be from a disposable/temporary email service")
                .timestamp(java.time.Instant.now().toString())
                .build();
    }
    
    /**
     * Create a response for a legitimate email
     */
    public static EmailVerificationResponse legitimate(String email, String domain) {
        return EmailVerificationResponse.builder()
                .email(email)
                .domain(domain)
                .isValid(true)
                .isDisposable(false)
                .isSuspicious(false)
                .message("Email domain appears to be legitimate")
                .timestamp(java.time.Instant.now().toString())
                .build();
    }
    
    /**
     * Create a response for an invalid email
     */
    public static EmailVerificationResponse invalid(String email, String message) {
        return EmailVerificationResponse.builder()
                .email(email)
                .domain("")
                .isValid(false)
                .isDisposable(false)
                .isSuspicious(true)
                .message(message)
                .timestamp(java.time.Instant.now().toString())
                .build();
    }
} 