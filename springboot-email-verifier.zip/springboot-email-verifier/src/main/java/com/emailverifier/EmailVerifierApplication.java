package com.emailverifier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/**
 * Main Spring Boot application class for Email Domain Verifier
 * 
 * This application provides:
 * - REST API endpoints for email domain verification
 * - Web interface for interactive email checking
 * - In-memory H2 database with disposable domain data
 * - Caching for improved performance
 */
@SpringBootApplication
@EnableCaching
public class EmailVerifierApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmailVerifierApplication.class, args);
    }
} 