// Email verification JavaScript for Spring Boot version

document.addEventListener('DOMContentLoaded', function() {
    const emailForm = document.getElementById('emailForm');
    const bulkForm = document.getElementById('bulkForm');
    const emailInput = document.getElementById('emailInput');
    const bulkEmails = document.getElementById('bulkEmails');
    const verifyBtn = document.getElementById('verifyBtn');
    const bulkVerifyBtn = document.getElementById('bulkVerifyBtn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const resultsSection = document.getElementById('resultsSection');
    const resultContent = document.getElementById('resultContent');
    const bulkResults = document.getElementById('bulkResults');
    const bulkResultContent = document.getElementById('bulkResultContent');

    // Single email verification
    if (emailForm) {
        emailForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = emailInput.value.trim();
            if (!email) {
                showAlert('Please enter an email address', 'warning');
                return;
            }

            if (!isValidEmail(email)) {
                showAlert('Please enter a valid email address', 'danger');
                return;
            }

            await verifyEmail(email);
        });
    }

    // Bulk email verification
    if (bulkForm) {
        bulkForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const emailsText = bulkEmails.value.trim();
            if (!emailsText) {
                showAlert('Please enter at least one email address', 'warning');
                return;
            }

            const emails = emailsText.split('\n')
                .map(email => email.trim())
                .filter(email => email.length > 0);

            if (emails.length === 0) {
                showAlert('Please enter valid email addresses', 'warning');
                return;
            }

            if (emails.length > 100) {
                showAlert('Maximum 100 emails allowed per request', 'danger');
                return;
            }

            await verifyBulkEmails(emails);
        });
    }

    // Real-time email validation
    if (emailInput) {
        emailInput.addEventListener('input', function() {
            const email = this.value.trim();
            if (email && !isValidEmail(email)) {
                this.classList.add('is-invalid');
            } else {
                this.classList.remove('is-invalid');
            }
        });
    }

    async function verifyEmail(email) {
        try {
            setButtonLoading(verifyBtn, true);
            showLoadingSpinner(true);
            hideResults();

            const response = await fetch('/api/verify', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email: email })
            });

            const data = await response.json();

            if (response.ok) {
                displayResult(data);
                showAlert('Email verification completed', 'success');
            } else {
                throw new Error(data.message || 'Verification failed');
            }

        } catch (error) {
            console.error('Error verifying email:', error);
            displayError(error.message);
            showAlert('Error verifying email: ' + error.message, 'danger');
        } finally {
            setButtonLoading(verifyBtn, false);
            showLoadingSpinner(false);
        }
    }

    async function verifyBulkEmails(emails) {
        try {
            setButtonLoading(bulkVerifyBtn, true);
            hideBulkResults();

            const response = await fetch('/api/bulk-verify', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ emails: emails })
            });

            const data = await response.json();

            if (response.ok) {
                displayBulkResults(data);
                showAlert(`Verified ${data.total} emails`, 'success');
            } else {
                throw new Error(data.message || 'Bulk verification failed');
            }

        } catch (error) {
            console.error('Error verifying bulk emails:', error);
            displayBulkError(error.message);
            showAlert('Error verifying emails: ' + error.message, 'danger');
        } finally {
            setButtonLoading(bulkVerifyBtn, false);
        }
    }

    function displayResult(data) {
        const resultClass = data.isDisposable ? 'danger' : 'success';
        const icon = data.isDisposable ? 'fas fa-exclamation-triangle' : 'fas fa-check-circle';
        const statusText = data.isDisposable ? 'Suspicious' : 'Legitimate';
        
        resultContent.innerHTML = `
            <div class="card result-card ${resultClass} animate-slide-in">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h5 class="card-title mb-2">
                                <i class="${icon} text-${resultClass} me-2"></i>
                                Email Status: <span class="text-${resultClass}">${statusText}</span>
                            </h5>
                            <p class="card-text mb-2">
                                <strong>Email:</strong> <code>${data.email}</code><br>
                                <strong>Domain:</strong> <code>${data.domain}</code>
                            </p>
                            <p class="card-text text-muted">${data.message}</p>
                        </div>
                        <div class="col-md-4 text-md-end">
                            <div class="mb-2">
                                <span class="badge ${data.isValid ? 'bg-success' : 'bg-danger'} me-1">
                                    ${data.isValid ? 'Valid Format' : 'Invalid Format'}
                                </span>
                            </div>
                            <div class="mb-2">
                                <span class="badge ${data.isDisposable ? 'bg-danger' : 'bg-success'} me-1">
                                    ${data.isDisposable ? 'Disposable' : 'Legitimate'}
                                </span>
                            </div>
                            <div>
                                <span class="badge ${data.isSuspicious ? 'bg-warning text-dark' : 'bg-success'} me-1">
                                    ${data.isSuspicious ? 'Suspicious' : 'Safe'}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        showResults();
    }

    function displayBulkResults(data) {
        const { results, total, disposableCount, suspiciousCount } = data;
        
        let tableRows = '';
        results.forEach((result, index) => {
            const statusClass = result.isDisposable ? 'table-danger' : 'table-success';
            const icon = result.isDisposable ? 'fas fa-times-circle text-danger' : 'fas fa-check-circle text-success';
            
            tableRows += `
                <tr class="${statusClass}">
                    <td>${index + 1}</td>
                    <td><code>${result.email}</code></td>
                    <td><code>${result.domain}</code></td>
                    <td class="text-center"><i class="${icon}"></i></td>
                    <td>
                        <span class="badge ${result.isDisposable ? 'bg-danger' : 'bg-success'}">
                            ${result.isDisposable ? 'Disposable' : 'Legitimate'}
                        </span>
                    </td>
                    <td class="small text-muted">${result.message}</td>
                </tr>
            `;
        });

        bulkResultContent.innerHTML = `
            <div class="animate-slide-in">
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <div class="card border-primary">
                            <div class="card-body text-center">
                                <h5 class="text-primary mb-1">${total}</h5>
                                <small class="text-muted">Total Verified</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card border-success">
                            <div class="card-body text-center">
                                <h5 class="text-success mb-1">${total - disposableCount}</h5>
                                <small class="text-muted">Legitimate</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card border-danger">
                            <div class="card-body text-center">
                                <h5 class="text-danger mb-1">${disposableCount}</h5>
                                <small class="text-muted">Disposable</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card border-warning">
                            <div class="card-body text-center">
                                <h5 class="text-warning mb-1">${suspiciousCount}</h5>
                                <small class="text-muted">Suspicious</small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Email</th>
                                <th scope="col">Domain</th>
                                <th scope="col" class="text-center">Status</th>
                                <th scope="col">Type</th>
                                <th scope="col">Message</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tableRows}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
        
        showBulkResults();
    }

    function displayError(message) {
        resultContent.innerHTML = `
            <div class="alert alert-danger animate-slide-in" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>
                <strong>Error:</strong> ${message}
            </div>
        `;
        showResults();
    }

    function displayBulkError(message) {
        bulkResultContent.innerHTML = `
            <div class="alert alert-danger animate-slide-in" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>
                <strong>Error:</strong> ${message}
            </div>
        `;
        showBulkResults();
    }

    function showLoadingSpinner(show) {
        if (show) {
            loadingSpinner.classList.remove('d-none');
        } else {
            loadingSpinner.classList.add('d-none');
        }
    }

    function showResults() {
        resultsSection.classList.remove('d-none');
    }

    function hideResults() {
        resultsSection.classList.add('d-none');
    }

    function showBulkResults() {
        bulkResults.classList.remove('d-none');
    }

    function hideBulkResults() {
        bulkResults.classList.add('d-none');
    }

    function setButtonLoading(button, loading = true) {
        if (loading) {
            button.disabled = true;
            button.dataset.originalText = button.innerHTML;
            button.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status"></span>Loading...';
        } else {
            button.disabled = false;
            button.innerHTML = button.dataset.originalText || button.innerHTML;
        }
    }

    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    function showAlert(message, type = 'info') {
        // Create alert element
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
        alertDiv.style.zIndex = '1050';
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(alertDiv);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }

    console.log('Email Verifier JavaScript (Spring Boot) loaded successfully');
}); 